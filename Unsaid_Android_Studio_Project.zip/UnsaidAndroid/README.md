# Unsaid — Android Studio project

**Launcher/app name:** Unsaid  
**Application ID:** `com.unsaid.diary` — keep stable for future updates.

## Open and build
1. Extract this ZIP into a folder.
2. Open Android Studio and choose **Open**, then select the extracted `UnsaidAndroid` folder (the folder containing `settings.gradle`).
3. Allow Gradle sync and install any SDK platform/build tools Android Studio requests.
4. Use **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio will show a link to the generated debug APK. Install it on your test phone.

The included `.github/workflows/build-apk.yml` is an optional cloud build workflow for GitHub Actions. Upload the project contents to a repository, run the workflow, then download the `Unsaid-debug-apk` artifact.

## What is included
- Android application shell with the app label **Unsaid**.
- Custom launcher icon (adaptive and legacy icon resources).
- Offline HTML interface bundled inside the app; no remote webpage is required.
- Requested interface changes: the main header says **Unsaid**, and the Writing Room does not include a second Scrapbook mode; the separate Scrapbook Studio remains in navigation.
- WebView file chooser support for selecting local photos and audio files.

## Important limits — please read
This is a buildable starter Android project, **not a guarantee of a bug-free final product**. It wraps the bundled HTML/JavaScript prototype in a WebView. The project has not been built or tested on a physical Android phone in this environment. Some features may behave differently in WebView than in a full native implementation.

In particular, this project does **not** yet provide native background music playback/notification controls, hardware-backed secure storage, true app-level encryption of all diary data, real Android launcher-icon switching, or a complete automated test suite. The prototype's icon selector only changes the in-app preference. The browser-style PIN feature is not a substitute for encryption. Do not keep the only copy of important writing here until you have tested backup and restore.

## Privacy and data
- App ID is kept stable for future updates.
- Prototype entries are stored in WebView local storage and may be lost if app data is cleared or the app is uninstalled.
- Existing browser-prototype data does not automatically migrate into this Android app.
- Export backups and keep a copy somewhere separate. Test restoring a backup before trusting it.

## Suggested test checklist before relying on it
1. Create, edit, favourite, lock and delete an entry; restore it from Recently Deleted.
2. Create a scrapbook page, add a photo and text, move objects, save and reopen the page, then export PNG.
3. Export a backup and restore it into a test copy; confirm entries and photos are present.
4. Import audio and test playback, then lock the screen and leave the app to see what the WebView player supports.
5. Test on the exact Android version/device you plan to use.
