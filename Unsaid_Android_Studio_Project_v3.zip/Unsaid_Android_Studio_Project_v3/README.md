# Unsaid Android Studio Project (Prototype v3)

This Android Studio project wraps the exact `Unsaid_Updated_Prototype_v3.html` prototype in a native Android WebView. The HTML is copied unchanged to `app/src/main/assets/index.html`.

## Open/build
1. Extract this ZIP.
2. In Android Studio choose **Open** and select the extracted `Unsaid_Android_Studio_Project_v3` folder.
3. Allow Gradle sync to finish, then run the `app` configuration on a device/emulator.
4. To create a debug APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

Application ID: `com.unsaid.diary`
Launcher label: `Unsaid`

## Important scope note
This is a WebView-based Android wrapper for the HTML prototype, not a full rewrite into native Android screens. The launcher icon is supplied by Android resources. Browser-style data stored in WebView local storage remains local to the app installation; clearing app data/uninstalling may remove it. Some browser features (especially downloading generated `blob:` files and background audio after the app is closed) may require further native integration and device testing.

The project has not been built on a real Android device in this environment, so please treat this as a project package, not a guarantee of zero bugs.
